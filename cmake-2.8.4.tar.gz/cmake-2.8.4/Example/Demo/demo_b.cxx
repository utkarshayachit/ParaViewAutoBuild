#include "hello.h"

Hello hello;
