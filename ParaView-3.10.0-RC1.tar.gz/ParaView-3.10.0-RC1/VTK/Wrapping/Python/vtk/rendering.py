""" This module loads all the classes from the VTK Rendering library into
its namespace.  This is an optional module."""

from vtkRenderingPython import *
