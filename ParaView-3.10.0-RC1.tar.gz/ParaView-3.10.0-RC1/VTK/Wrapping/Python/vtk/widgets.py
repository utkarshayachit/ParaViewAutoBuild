""" This module loads all the classes from the VTK Widgets library
into its namespace.  This is an optional module."""

from vtkWidgetsPython import *
