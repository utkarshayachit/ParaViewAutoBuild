""" This module loads all the required VTK libraries."""

# Load all required kits.
from vtkCommonPython import *
from vtkFilteringPython import *
from vtkIOPython import *
from vtkImagingPython import *
from vtkGraphicsPython import *
