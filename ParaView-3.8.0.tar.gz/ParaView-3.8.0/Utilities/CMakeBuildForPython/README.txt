In this directory you can find CMake files for building Python.

The files in cvs HEAD are for Python 2.5.1.

Just copy them into your Python source directory and run cmake on them.

This has been tested on Linux, eCos, IBM BlueGene/L and partly on Windows.

The interpreter is built, there are install rules for most stuff, and a
package can be built.

Not all library modules are built and installed.


Alex

