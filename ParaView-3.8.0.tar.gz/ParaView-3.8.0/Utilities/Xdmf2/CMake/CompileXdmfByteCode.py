import compileall
import sys

compileall.compile_dir(sys.argv[1])
